from PIL import Image
import sys

def check(path):
    im = Image.open(path).convert("RGBA")
    w, h = im.size
    px = im.load()

    # --- border RGB ---
    rs, gs, bs = [], [], []
    for x in range(w):
        r,g,b,a = px[x,0]
        rs.append(r); gs.append(g); bs.append(b)
        r,g,b,a = px[x,h-1]
        rs.append(r); gs.append(g); bs.append(b)
    for y in range(h):
        r,g,b,a = px[0,y]
        rs.append(r); gs.append(g); bs.append(b)
        r,g,b,a = px[w-1,y]
        rs.append(r); gs.append(g); bs.append(b)

    print("border rgb avg :", [
        round(sum(rs)/len(rs),1),
        round(sum(gs)/len(gs),1),
        round(sum(bs)/len(bs),1)
    ])

    # --- alpha check ---
    a = im.getchannel("A")
    ab = []
    for x in range(w):
        ab.append(a.getpixel((x,0)))
        ab.append(a.getpixel((x,h-1)))
    for y in range(h):
        ab.append(a.getpixel((0,y)))
        ab.append(a.getpixel((w-1,y)))

    print("border alpha min/max :", (min(ab), max(ab)))
    print("alpha extrema :", a.getextrema())


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python check_border_rgb.py image.png")
    else:
        check(sys.argv[1])
