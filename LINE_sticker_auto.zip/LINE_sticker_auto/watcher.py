﻿import time
import shutil
import subprocess
import zipfile
import csv
from pathlib import Path
from typing import Optional


# =====================
# パス
# =====================
ROOT = Path(__file__).resolve().parent

VIDEOS = ROOT / "videos"
DONE = ROOT / "videos_done"
FAILED = ROOT / "videos_failed"

DIST_DIR = ROOT / "dist"
APNG_DIR = DIST_DIR / "apng"
REPORT_CSV = DIST_DIR / "report.csv"

SUBMIT = ROOT / "submit"

for d in [VIDEOS, DONE, FAILED, DIST_DIR, APNG_DIR, SUBMIT]:
    d.mkdir(parents=True, exist_ok=True)


# =====================
# build_apng.py 実行
# =====================
def run_build_apng() -> int:
    print("▶ build_apng.py 実行中...")
    p = subprocess.run(
        ["python", "-u", "build_apng.py"],
        cwd=str(ROOT),
        text=True
    )
    print(f"▶ build_apng.py 終了 (returncode={p.returncode})")
    print(f"▶ report expected: {REPORT_CSV}")
    return p.returncode


# =====================
# report.csv から APNG を探す（新方式）
# =====================
def find_apng_for_mp4_from_report(mp4_name: str) -> Optional[Path]:
    if not REPORT_CSV.exists():
        return None

    with REPORT_CSV.open("r", encoding="utf-8-sig", newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            src = (row.get("src_filename") or "").strip()
            status = (row.get("status") or "").strip().lower()
            apng_path = (row.get("apng_path") or "").strip()
            if status == "ok" and src == mp4_name and apng_path:
                p = Path(apng_path)
                if p.exists():
                    return p
    return None


# =====================
# APNG探索（互換）
# =====================
def find_best_apng_for_mp4(mp4_name: str) -> Optional[Path]:
    # 1) report.csv 優先
    p = find_apng_for_mp4_from_report(mp4_name)
    if p:
        return p

    # 2) 旧方式（stem一致）
    stem = Path(mp4_name).stem
    candidates = list(APNG_DIR.glob(f"{stem}_*.png"))
    if candidates:
        candidates.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        return candidates[0]

    legacy = APNG_DIR / f"{stem}.png"
    if legacy.exists():
        return legacy

    # 3) 最終保険：最新png
    all_png = list(APNG_DIR.glob("*.png"))
    if all_png:
        all_png.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        return all_png[0]

    return None


# =====================
# APNGから先頭フレームをサムネとして保存（ffmpeg）
# 重要：拡張子が .png でも中身がAPNGなので、入力 -f apng を明示
# =====================
def extract_first_frame_from_apng(apng_path: Path, batch_dir: Path) -> Path:
    out_png = batch_dir / "thumb.png"

    cmd = [
        "ffmpeg", "-y",
        "-f", "apng",
        "-i", str(apng_path),
        "-frames:v", "1",
        "-pix_fmt", "rgba",
        str(out_png),
    ]

    p = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if p.returncode != 0:
        raise RuntimeError(f"ffmpeg thumb failed:\n{p.stderr}")

    return out_png


# =====================
# MP4処理
# =====================
def process_current_videos():
    mp4s = list(VIDEOS.glob("*.mp4"))
    if not mp4s:
        return

    run_build_apng()

    ts = time.strftime("%Y%m%d_%H%M%S")
    batch = SUBMIT / f"batch_{ts}"
    upload_dir = batch / "upload"
    apng_out_dir = batch / "apng"

    upload_dir.mkdir(parents=True, exist_ok=True)
    apng_out_dir.mkdir(parents=True, exist_ok=True)

    copied_rows = []
    copied_apng_paths = []

    for mp4 in mp4s:
        apng = find_best_apng_for_mp4(mp4.name)
        if apng and apng.exists():
            # batch/apng にコピー
            dst1 = apng_out_dir / apng.name
            shutil.copy2(apng, dst1)
            copied_apng_paths.append(dst1)

            # batch/upload にコピー（ZIP対象）
            dst2 = upload_dir / apng.name
            shutil.copy2(apng, dst2)

            size = apng.stat().st_size
            copied_rows.append((apng.name, size, "ok"))

            dst = DONE / mp4.name
            if mp4.exists():
                try:
                    shutil.move(str(mp4), str(dst))
                except FileNotFoundError:
                    # 他処理で既に移動/削除された
                    pass
            else:
                # 既に無い（他処理で移動済みなど）
                pass

        else:
            shutil.move(str(mp4), FAILED / mp4.name)

    if not copied_rows:
        print("⚠ 成功が0件でした（APNGも見つかりませんでした）")
        print(f"   確認: {APNG_DIR} に *.png が出来ているか見てください")
        return

    # サムネ生成（ffmpeg）
    base_apng = copied_apng_paths[0]
    extract_first_frame_from_apng(base_apng, batch)

    # 一覧CSV
    with (batch / "list.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["apng_file", "bytes", "detail"])
        for row in copied_rows:
            w.writerow(row)

    # ZIP作成
    zip_path = batch / "upload.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in upload_dir.glob("*.png"):
            z.write(p, arcname=p.name)

    print(f"✅ 提出用ZIP: {zip_path}")


# =====================
# 監視ループ
# =====================
def main():
    print(f"📂 watcher 起動（監視開始）: {VIDEOS}")
    print("  - MP4を videos/ に入れると自動で処理します")
    print("  - 停止: Ctrl + C")

    try:
        while True:
            process_current_videos()
            time.sleep(2)
    except KeyboardInterrupt:
        print("🛑 watcher 停止")


if __name__ == "__main__":
    main()
